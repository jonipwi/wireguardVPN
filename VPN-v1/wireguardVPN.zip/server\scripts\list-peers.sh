#!/usr/bin/env bash
set -euo pipefail
sudo wg show
