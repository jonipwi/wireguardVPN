# Windows Client

1) Install WireGuard for Windows from the official site.
2) Obtain your `*.conf` file from the server admin.
3) Double-click the `.conf` or import it in the WireGuard app.
4) Click Activate.

The `install.ps1` script can import all `*.conf` files in this folder into the Windows WireGuard app.
